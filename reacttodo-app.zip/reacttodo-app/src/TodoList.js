import React, { useState } from 'react';
function TodoList(){
    const[activity,setActivity]=useState("");
    const[listdata,setlistdata]=useState([]);
    const handleOnChange = (event)=>{
        setActivity(event.target.value)
    }
    function addActivity(){
        setlistdata((listdata)=>{
           const updatedList=[...listdata,activity];
           setActivity('');
           return updatedList;
    })
    }
    return(
        <>
        <div className="container">
            <div className="header">TODO LIST</div>
            <input type="text" placeholder='Add activity' value={activity} onChange={handleOnChange}></input>
            <button onClick={addActivity}>Add</button>
            <h3>Here is you List :</h3>
            {listdata!=[] && listdata.map((data,i)=>{
                return(
                    <>
                    <div key={i}>
                        <p className='listdata'>{data}</p>
                    </div>
                    </>
                )
            })}
        </div>

        </>
    )
}
export default TodoList